import os
import exiftool
import folium
import webbrowser
import sys

path = sys.argv[1]
latitude = sys.argv[2]
#latitude = int(latitude)
longitude = sys.argv[3]
#longitude = int(longitude)
map = folium.Map(location=[latitude, longitude], zoom_start=14)
the_dict = {}
walk = os.walk(path)
et = exiftool.ExifToolHelper()
i=0
for root, dir, files in walk:
        base = os.path.basename(root)
        for f in files:
                ext = f.split('.')[1]
                if ext == 'jpg':
                        the_dict[base] = files

print('Scanning jpg file complete...')

for key in the_dict.keys():
        for i in range(len(the_dict[key])):
                the_dict[key][i] = os.path.join(path,key,the_dict[key][i])

print ('Marking on map...')

for key in the_dict.items():
        grup = folium.FeatureGroup(name=key[0])
        map.add_child(grup)
        for val in key[1]:
                lat = et.execute('-b','-gpslatitude', val)
                lon = et.execute('-b','-gpslongitude', val)
                name = os.path.basename(val)
                name = name.split('.')[0]
                popup_template = '''
                                <!DOCTYPE html>
                                <head>
                                <style>
                                        img {
                                                border: 2px solid black;
                                                text-align: center;
                                                width: 150px;
                                                height: 150px;
                                        }
                                        p {
                                                color: #00ff00;
                                                text-align: center;
                                        }
                                </style>
                                </head>
                                <body>
                                        <img src='''+val+'''>
                                        <p>'''+name+'''</p>
                                </body>
                                </html>
                                '''
                the_popup = folium.Popup(html=popup_template)
                folium.Marker([lat,lon], popup=the_popup).add_to(grup)

folium.LayerControl().add_to(map)
map.save('plot.html')
webbrowser.open_new('plot.html')